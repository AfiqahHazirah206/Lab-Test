$
function showDetails(employeeNumber) {
        // Make an AJAX request to fetch staff details based on the email
      
        // Staff details
        var staffDetails = {
          '001': {
            employeeNumber: '001',
            firstName: 'David',
            lastName: 'Murphy',
            officeCode: 'A001',
            extension: '1234',
            email: 'dmurphy@gmail.com',
            jobTitle: 'Manager',
            reportsTo: 'CEO'
          },
          '002': {
            employeeNumber: '002',
            firstName: 'May',
            lastName: 'Patterson',
            officeCode: 'B002',
            extension: '5678',
            email: 'mpatterson@gmail.com',
            jobTitle: 'Engineer',
            reportsTo: 'Manager'
          },
          '003': {
            employeeNumber: '003',
            firstName: 'Wendy',
            lastName: 'Patterson',
            officeCode: 'C003',
            extension: '9101',
            email: 'wpatterson@gmail.com',
            jobTitle: 'Designer',
            reportsTo: 'Manager'
          },
          '004': {
            employeeNumber: '004',
            firstName: 'Leslie',
            lastName: 'Jennings',
            officeCode: 'D004',
            extension: '9243',
            email: 'ljennings@gmail.com',
            jobTitle: 'Manager',
            reportsTo: 'CEO'
          },
          '005': {
            employeeNumber: '005',
            firstName: 'Lily',
            lastName: 'Thompson',
            officeCode: 'E005',
            extension: '2553',
            email: 'lthompson@gmail.com',
            jobTitle: 'Engineer',
            reportsTo: 'Manager'
          },
          '006': {
            employeeNumber: '006',
            firstName: 'Amanda',
            lastName: 'Bow',
            officeCode: 'F006',
            extension: '4321',
            email: 'abow@gmail.com',
            jobTitle: 'Designer',
            reportsTo: 'Manager'
        }
        };
      
        var detailsContainer = document.getElementById('staff-details');
        var details = staffDetails[employeeNumber];
      
        if (details) {
          // Display staff details
          detailsContainer.innerHTML = `
            <h2>${details.firstName} ${details.lastName}</h2>
            <p><strong>Employee Number:</strong> ${details.employeeNumber}</p>
            <p><strong>Office Code:</strong> ${details.officeCode}</p>
            <p><strong>Extension:</strong> ${details.extension}</p>
            <p><strong>Email:</strong> ${details.email}</p>
            <p><strong>Job Title:</strong> ${details.jobTitle}</p>
            <p><strong>Reports To:</strong> ${details.reportsTo}</p>
          `;
        } else {
          // No staff details found
          detailsContainer.innerHTML = '<p>No details found for this staff member.</p>';
        }
      
        // Prevent the default link behavior
        return false;
      }
      